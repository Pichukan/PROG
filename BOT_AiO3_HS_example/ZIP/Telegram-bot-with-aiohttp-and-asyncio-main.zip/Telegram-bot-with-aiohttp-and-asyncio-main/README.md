# Из курса по ботам для Telegram YT канала Python Hub Studio.
Пример простого бота на python с aiohttp и asyncio, по взаимодействию с API Telegram
