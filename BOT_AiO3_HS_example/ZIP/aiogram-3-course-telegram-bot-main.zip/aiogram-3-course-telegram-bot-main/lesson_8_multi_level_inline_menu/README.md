Изображения баннеров в папке lesson_8 template.
Код из видео yt канала Python Hub Studio.
