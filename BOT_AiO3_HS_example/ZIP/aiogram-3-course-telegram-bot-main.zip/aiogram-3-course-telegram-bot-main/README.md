# Код из каждого видео плейлиста в отдельной папке lesson_1, 2, .. и так далее
Код из курса по созданию бота для Telegram на python с aiogram 3, YT канала Python Hub Studio

Код дополнительного примера из второго видео, по работе с API Telegram напрямую через aiohttp:
https://github.com/PythonHubStudio/Telegram-bot-with-aiohttp-and-asyncio
